package gen3check.observers;

import java.util.List;

import gen3check.PokemonFoundData;

public class PokemonListContainerObserverHelper implements PokemonListContainerObserver{

	@Override
	public void pokemonListChange(List<PokemonFoundData> pList) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void pokemonSelectionChange(PokemonFoundData current) {
		// TODO Auto-generated method stub
		
	}
}
